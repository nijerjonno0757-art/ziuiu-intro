import {Config} from "@remotion/cli/config";

// H.264 + AAC MP4 (procedural SFX), crisp vector edges.
Config.setCodec("h264");
Config.setPixelFormat("yuv420p");
Config.setVideoImageFormat("png");
Config.setCrf(16);
Config.setAudioCodec("aac");
Config.setOverwriteOutput(true);
