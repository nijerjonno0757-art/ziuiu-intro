import React from "react";
import {HEIGHT, WIDTH} from "./config";
import {getPose, T} from "./pose";
import {TitleDefs, TitleLayer} from "./Title";
import {ZombieBack, ZombieFront} from "./Zombie";
import {tween, inOutCubic} from "./utils";

/** Pure renderer: everything is a function of the frame number. */
export const Stage: React.FC<{frame: number}> = ({frame}) => {
  const pose = getPose(frame);
  const fade = tween(frame, [T.fadeStart, T.end], [1, 0], inOutCubic);
  // While the title is still small it lives *inside* the mouth (behind the teeth).
  const titleInsideMouth = frame < T.titleStart + 11;
  // "boiling line" hand-drawn wobble: new noise seed every 3 frames
  const seed = Math.floor(frame / 3) % 7;

  return (
    <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{display: "block"}}>
      <rect width={WIDTH} height={HEIGHT} fill="#000" />
      <defs>
        <filter id="boil" filterUnits="userSpaceOnUse" x={0} y={0} width={WIDTH} height={HEIGHT} colorInterpolationFilters="sRGB">
          <feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves={1} seed={seed} result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale={6} xChannelSelector="R" yChannelSelector="G" />
        </filter>
      </defs>
      <TitleDefs />
      <g opacity={fade} filter="url(#boil)">
        <ZombieBack pose={pose} />
        {titleInsideMouth && <TitleLayer frame={frame} />}
        <ZombieFront pose={pose} />
        {!titleInsideMouth && <TitleLayer frame={frame} />}
      </g>
    </svg>
  );
};
