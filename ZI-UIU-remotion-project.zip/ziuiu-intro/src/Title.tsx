import React from "react";
import {Easing} from "remotion";
import {TITLE_TEXT, WIDTH} from "./config";
import {TITLE_FONT_STACK} from "./font";
import {mouthCenterOnStage, T} from "./pose";
import {clamp01, lerp, outCubic, tween} from "./utils";

const FONT_SIZE = 330;
const TEXT_WIDTH = 800; // final width -> 140px side margins on a 1080px canvas
const CENTER: [number, number] = [WIDTH / 2, 960];
const FLY_EASE = Easing.bezier(0.45, 0, 0.15, 1);

export const TitleDefs: React.FC = () => (
  <defs>
    <linearGradient id="tGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#d6ffb8" />
      <stop offset="0.35" stopColor="#5dff2a" />
      <stop offset="1" stopColor="#1fd10f" />
    </linearGradient>
    <filter id="tGlow" x="-20%" y="-40%" width="140%" height="180%" colorInterpolationFilters="sRGB">
      <feGaussianBlur stdDeviation="16" />
    </filter>
  </defs>
);

const textProps = {
  textAnchor: "middle" as const,
  dy: "0.35em",
  fontFamily: TITLE_FONT_STACK,
  fontSize: FONT_SIZE,
  textLength: TEXT_WIDTH,
  lengthAdjust: "spacingAndGlyphs" as const,
  strokeLinejoin: "round" as const,
};

export const TitleLayer: React.FC<{frame: number}> = ({frame}) => {
  if (frame < T.titleStart) return null;
  const [sx0, sy0] = mouthCenterOnStage(T.titleStart);

  // flight: out of the mouth, towards the viewer, to the centre
  const p = tween(frame, [T.titleStart, T.titleLand], [0, 1], FLY_EASE);
  const x = lerp(sx0, CENTER[0], p);
  const y = lerp(sy0, CENTER[1], p);

  // cartoon landing: damped spring with squash & stretch
  const d = Math.max(0, frame - T.titleLand);
  const spring = Math.exp(-0.2 * d) * Math.cos(0.5 * d);
  const fly = tween(frame, [T.titleStart, T.titleLand], [0.08, 1.18], FLY_EASE);
  const s = frame < T.titleLand ? fly : 1 + 0.18 * spring;
  const squash = clamp01((frame - T.titleLand) / 3);
  const sx = s;
  const sy = s - (s - 1) * 1.3 * squash;
  const rot =
    frame < T.titleLand
      ? tween(frame, [T.titleStart, T.titleLand], [-30, 4], FLY_EASE)
      : 4 * spring;

  const glow = 0.55 + 0.15 * Math.sin(frame / 6);

  // slime droplets burst out of the mouth
  const pt = (frame - (T.titleStart + 2)) / 24;
  const drops =
    pt > 0 && pt < 1
      ? Array.from({length: 10}, (_, i) => {
          const a = ((i * 36 + (i % 2) * 14 - 90) * Math.PI) / 180;
          const dist = 50 + 340 * outCubic(pt) * (0.7 + (i % 3) * 0.2);
          return (
            <circle
              key={i}
              cx={sx0 + Math.cos(a) * dist}
              cy={sy0 + Math.sin(a) * dist}
              r={4 + (14 - (i % 4) * 3) * (1 - pt)}
              fill="#39ff14"
              stroke="#0b4d12"
              strokeWidth={3}
              opacity={1 - pt * pt}
            />
          );
        })
      : null;

  const extrusion = Array.from({length: 9}, (_, i) => 9 - i);

  return (
    <g>
      {drops}
      <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${sx} ${sy})`}>
        {/* neon glow */}
        <text {...textProps} fill="#39ff14" stroke="#39ff14" strokeWidth={22} opacity={glow} filter="url(#tGlow)">
          {TITLE_TEXT}
        </text>
        {/* cartoon extrusion */}
        {extrusion.map((o) => (
          <text key={o} {...textProps} x={o * 1.6} y={o * 2.2} fill="#06300c" stroke="#06300c" strokeWidth={16}>
            {TITLE_TEXT}
          </text>
        ))}
        {/* dark green outline */}
        <text {...textProps} fill="#0b5a1a" stroke="#0b5a1a" strokeWidth={18}>
          {TITLE_TEXT}
        </text>
        {/* neon fill */}
        <text {...textProps} fill="url(#tGrad)" stroke="#0e7a22" strokeWidth={4} paintOrder="stroke fill">
          {TITLE_TEXT}
        </text>
      </g>
    </g>
  );
};
