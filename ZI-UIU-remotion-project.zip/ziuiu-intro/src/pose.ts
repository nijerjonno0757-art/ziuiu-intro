import {Easing} from "remotion";
import {getMouth} from "./geometry";
import {keyframes, tween} from "./utils";

/**
 * Master timeline (30 fps):
 *   0 - 60   rise from the bottom
 *  60 -120   look at camera, blink, tilt, creepy smile
 * 120 -180   mouth opens wider and wider
 * 180 -240   title pops out of the mouth and lands (jaw closes into a grin)
 * 240 -300   zombie slides aside and peeks from behind the title, fade out
 */
export const T = {
  riseEnd: 60,
  lookStart: 60,
  blinkStart: 84,
  blinkEnd: 92,
  mouthStart: 120,
  mouthEnd: 180,
  titleStart: 180,
  titleLand: 206,
  peekStart: 236,
  peekEnd: 268,
  fadeStart: 272,
  end: 299,
} as const;

export interface Pose {
  // whole body, screen space (px = screen position of local point (400, 900))
  px: number;
  py: number;
  scale: number;
  rot: number;
  // head
  headTilt: number;
  // eyes
  lookX: number;
  lookY: number;
  blink: number;
  droop: number;
  eyeWide: number;
  brow: number;
  pupil: number;
  // mouth
  smile: number;
  jaw: number;
}

export const BODY_PIVOT: [number, number] = [400, 900];
export const NECK_PIVOT: [number, number] = [400, 780];

export const getPose = (frame: number): Pose => {
  const f = frame;

  // ---- body placement ----------------------------------------------------
  const rise = tween(f, [0, T.riseEnd + 4], [1750, 0], Easing.bezier(0.3, 0.05, 0.2, 1));
  const move = (a: number, b: number) =>
    tween(f, [T.peekStart, T.peekEnd], [a, b], Easing.inOut(Easing.cubic));

  const thrust = keyframes(f, [[176, 0], [184, 1], [204, 0]], Easing.inOut(Easing.sin));
  const shake = f >= 180 && f < 200 ? Math.sin(f * 3.1) * 4 * (1 - (f - 180) / 20) : 0;
  const breathe = Math.sin(f / 15) * 5 * tween(f, [50, 70], [0, 1]);
  const sway = Math.sin(f / 23) * 4 * tween(f, [50, 70], [0, 1]);

  const px = move(540, 740) + sway + shake;
  const py = move(1470, 1640) + rise + breathe;
  const scale = move(1.5, 0.95) * (1 + 0.05 * thrust) * (1 + Math.sin(f / 15) * 0.004);
  const rot = move(0, -8) + Math.sin(f / 31) * 0.5;

  // ---- head ----------------------------------------------------------------
  const headTilt = keyframes(
    f,
    [[0, 0], [96, 0], [122, 9], [172, 4], [186, -4], [240, 0], [270, -7], [299, -8]],
    Easing.inOut(Easing.sin),
  );

  // ---- eyes ----------------------------------------------------------------
  const lookX = keyframes(f, [[0, -14], [56, -14], [76, 0], [234, 0], [246, -16], [258, -16], [272, 0]]);
  const lookY = keyframes(f, [[0, 12], [56, 12], [76, 0], [234, 0], [246, -9], [258, -9], [272, 0]]);
  const blink = keyframes(f, [[0, 0], [T.blinkStart, 0], [88, 1], [T.blinkEnd, 0]], Easing.inOut(Easing.sin));
  const droop = keyframes(f, [[0, 0.3], [56, 0.3], [76, 0.16], [120, 0.16], [150, 0], [240, 0], [272, 0.2]]);
  const eyeWide = keyframes(f, [[0, 1], [120, 1], [170, 1.12], [204, 1.12], [240, 1]]);
  const brow = keyframes(f, [[0, 0], [120, 0], [170, -14], [206, -14], [240, 0]]);
  const pupil = keyframes(f, [[0, 1], [120, 1], [175, 0.7], [206, 0.7], [240, 1]]);

  // ---- mouth ---------------------------------------------------------------
  const smile = keyframes(
    f,
    [[0, 0], [100, 0], [122, 1], [150, 1], [178, 0.4], [206, 0.4], [238, 1], [299, 1.12]],
    Easing.inOut(Easing.sin),
  );
  let jaw: number;
  if (f < T.mouthEnd) {
    jaw = tween(f, [T.mouthStart, T.mouthEnd], [0, 235], Easing.inOut(Easing.quad));
  } else {
    jaw = keyframes(f, [[180, 235], [186, 250], [206, 245], [238, 0]]);
  }
  // nervous tremble while the jaw is stretched
  jaw += Math.sin(f * 1.9) * 3 * (jaw / 250);
  jaw = Math.max(0, jaw);

  return {px, py, scale, rot, headTilt, lookX, lookY, blink, droop, eyeWide, brow, pupil, smile, jaw};
};

/** Convert a point in zombie-local space to stage (screen) space. */
export const toStage = (pose: Pose, [x, y]: [number, number]): [number, number] => {
  // head tilt about the neck
  const ht = (pose.headTilt * Math.PI) / 180;
  let dx = x - NECK_PIVOT[0];
  let dy = y - NECK_PIVOT[1];
  let hx = NECK_PIVOT[0] + dx * Math.cos(ht) - dy * Math.sin(ht);
  let hy = NECK_PIVOT[1] + dx * Math.sin(ht) + dy * Math.cos(ht);
  // body transform
  const r = (pose.rot * Math.PI) / 180;
  dx = (hx - BODY_PIVOT[0]) * pose.scale;
  dy = (hy - BODY_PIVOT[1]) * pose.scale;
  return [
    pose.px + dx * Math.cos(r) - dy * Math.sin(r),
    pose.py + dx * Math.sin(r) + dy * Math.cos(r),
  ];
};

export const mouthCenterOnStage = (frame: number): [number, number] => {
  const pose = getPose(frame);
  const m = getMouth(pose.smile, pose.jaw);
  return toStage(pose, m.center);
};
