import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {useTitleFont} from "./font";
import {Sfx} from "./Sfx";
import {Stage} from "./Stage";

export const ZIUIUIntro: React.FC = () => {
  const frame = useCurrentFrame();
  useTitleFont();
  return (
    <AbsoluteFill style={{backgroundColor: "#000"}}>
      <Stage frame={frame} />
      <Sfx />
    </AbsoluteFill>
  );
};
