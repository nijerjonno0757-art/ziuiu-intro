import React from "react";
import {getMouth} from "./geometry";
import {BODY_PIVOT, NECK_PIVOT, Pose} from "./pose";
import {clamp01} from "./utils";

/**
 * The ZI-UIU zombie mascot, drawn entirely with SVG primitives.
 * Coordinate space: 800 x 1250 local units (head ~ y150-725, shirt to y1250).
 *
 * It is split into two layers so the title can sit *between* them while it is
 * still inside the mouth:
 *   ZombieBack  - body, neck, head, eyes, eyelids, mouth interior
 *   ZombieFront - teeth and lips (jaw rim)
 *
 * Every moving part is driven by the Pose: eyes (pupils), eyelids (upper and
 * lower), jaw/mouth, brows and head tilt are all animated independently.
 */

export const COLORS = {
  outline: "#0c150c",
  skin: "#7f9d69",
  skinLight: "#9db885",
  skinDark: "#547048",
  skinShadow: "#334a2e",
  eye: "#f2eaa0",
  eyeEdge: "#cfc46d",
  socket: "#1b1325",
  hair: "#09090c",
  hairRim: "#3a3a48",
  shirt: "#3a2150",
  shirtDark: "#24132f",
  shirtLight: "#51306c",
  tooth: "#dcc548",
  toothDark: "#8d7522",
  mouth: "#000000",
} as const;

const C = COLORS;

export const bodyTransform = (pose: Pose) =>
  `translate(${pose.px} ${pose.py}) rotate(${pose.rot}) scale(${pose.scale}) translate(${-BODY_PIVOT[0]} ${-BODY_PIVOT[1]})`;

const headTransform = (pose: Pose) =>
  `rotate(${pose.headTilt} ${NECK_PIVOT[0]} ${NECK_PIVOT[1]})`;

// ---------------------------------------------------------------------------
// Body (torn dark purple shirt)
// ---------------------------------------------------------------------------
const Body: React.FC = () => (
  <g strokeLinejoin="round" strokeLinecap="round">
    {/* neck */}
    <path d="M 352 650 L 346 840 L 454 840 L 448 650 Z" fill={C.skinDark} stroke={C.outline} strokeWidth={5} />
    <path d="M 374 700 L 380 820 M 426 700 L 420 820" stroke={C.skinShadow} strokeWidth={5} fill="none" />
    {/* shirt */}
    <path
      d="M 110 1250 L 116 930 C 126 862 215 828 335 802 L 465 802 C 585 828 674 862 684 930 L 690 1250 Z"
      fill="url(#zShirt)"
      stroke="#120a18"
      strokeWidth={6}
    />
    {/* torn, jagged collar opening showing the skinny chest */}
    <path
      d="M 322 802 L 338 842 L 352 824 L 370 874 L 392 902 L 400 944 L 408 902 L 430 874 L 448 824 L 462 842 L 478 802 Z"
      fill={C.skinDark}
      stroke="#120a18"
      strokeWidth={5}
    />
    <path d="M 340 816 Q 372 836 396 828 M 460 816 Q 428 836 404 828 M 400 830 L 400 920" stroke={C.skinShadow} strokeWidth={4} fill="none" />
    <path d="M 366 872 L 396 880 M 434 872 L 404 880" stroke={C.skinShadow} strokeWidth={4} fill="none" />
    {/* folds */}
    <path d="M 200 905 Q 232 1010 208 1120 M 250 880 Q 268 960 262 1010 M 600 905 Q 574 1010 596 1120 M 548 880 Q 534 960 540 1010"
      stroke={C.shirtDark} strokeWidth={6} fill="none" opacity={0.9} />
    {/* tear on the chest showing ribs */}
    <path d="M 176 1040 L 226 1018 L 252 1056 L 296 1034 L 290 1098 L 258 1128 L 228 1104 L 192 1122 Z"
      fill={C.skinDark} stroke="#120a18" strokeWidth={5} />
    <path d="M 206 1054 L 276 1050 M 204 1078 L 278 1074 M 212 1100 L 270 1098" stroke={C.skinShadow} strokeWidth={5} fill="none" />
    {/* torn right shoulder */}
    <path d="M 636 884 L 678 910 L 660 930 L 686 954 L 640 962 L 618 924 Z" fill={C.skinDark} stroke="#120a18" strokeWidth={5} />
    {/* stitched patch */}
    <g transform="rotate(6 555 1040)">
      <rect x={500} y={990} width={110} height={100} fill="#5b3a6e" stroke="#120a18" strokeWidth={5} />
      <rect x={510} y={1000} width={90} height={80} fill="none" stroke="#cdb9d8" strokeWidth={3.5} strokeDasharray="10 8" />
    </g>
  </g>
);

// ---------------------------------------------------------------------------
// Eye (socket, eyeball, veins, pupil, upper + lower eyelid)
// ---------------------------------------------------------------------------
interface EyeProps {
  id: string;
  cx: number;
  cy: number;
  rx: number;
  ry: number;
  rot: number;
  pupilR: number;
  lookX: number;
  lookY: number;
  pose: Pose;
  veins: string;
}

const Eye: React.FC<EyeProps> = ({id, cx, cy, rx, ry, rot, pupilR, lookX, lookY, pose, veins}) => {
  const rxw = rx * pose.eyeWide;
  const ryw = ry * pose.eyeWide;
  const upper = clamp01(Math.max(pose.droop, pose.blink));
  const lower = clamp01(pose.blink * 0.3 + pose.smile * 0.1);
  const lidY = cy - ryw + 2 * ryw * upper;
  const lowY = cy + ryw - 2 * ryw * lower;
  const maxX = rxw * 0.5;
  const maxY = ryw * 0.4;
  const px = cx + Math.max(-maxX, Math.min(maxX, lookX));
  const py = cy + Math.max(-maxY, Math.min(maxY, lookY));
  const x0 = cx - rxw - 6;
  const x1 = cx + rxw + 6;

  return (
    <g transform={`rotate(${rot} ${cx} ${cy})`}>
      <defs>
        <clipPath id={`${id}-clip`}>
          <ellipse cx={cx} cy={cy} rx={rxw} ry={ryw} />
        </clipPath>
      </defs>
      {/* dark sunken socket */}
      <ellipse cx={cx} cy={cy + 4} rx={rxw + 24} ry={ryw + 22} fill={C.socket} stroke={C.outline} strokeWidth={5} />
      {/* eyeball */}
      <ellipse cx={cx} cy={cy} rx={rxw} ry={ryw} fill="url(#zEye)" />
      <g clipPath={`url(#${id}-clip)`}>
        <path d={veins} transform={`translate(${cx} ${cy})`} stroke="#b0553b" strokeWidth={2.5} fill="none" opacity={0.7} />
        <circle cx={px} cy={py} r={pupilR * pose.pupil} fill="#060606" />
        <circle cx={px - pupilR * 0.35} cy={py - pupilR * 0.4} r={Math.max(2, pupilR * 0.28)} fill="#fff" opacity={0.85} />
        {/* upper eyelid */}
        <path
          d={`M ${x0} ${cy - ryw - 8} L ${x1} ${cy - ryw - 8} L ${x1} ${lidY} Q ${cx} ${lidY + 14} ${x0} ${lidY} Z`}
          fill={C.skinDark}
        />
        <path d={`M ${x0} ${lidY} Q ${cx} ${lidY + 14} ${x1} ${lidY}`} stroke={C.outline} strokeWidth={5} fill="none" />
        {/* lower eyelid */}
        <path
          d={`M ${x0} ${cy + ryw + 8} L ${x1} ${cy + ryw + 8} L ${x1} ${lowY} Q ${cx} ${lowY - 10} ${x0} ${lowY} Z`}
          fill={C.skin}
        />
        <path d={`M ${x0} ${lowY} Q ${cx} ${lowY - 10} ${x1} ${lowY}`} stroke={C.outline} strokeWidth={4} fill="none" />
      </g>
      <ellipse cx={cx} cy={cy} rx={rxw} ry={ryw} fill="none" stroke={C.outline} strokeWidth={5} />
      {/* bags under the eye */}
      <path
        d={`M ${cx - rxw * 0.8} ${cy + ryw + 34} Q ${cx} ${cy + ryw + 52} ${cx + rxw * 0.8} ${cy + ryw + 32}`}
        stroke={C.skinShadow}
        strokeWidth={5}
        fill="none"
        strokeLinecap="round"
        opacity={0.8}
      />
    </g>
  );
};

// ---------------------------------------------------------------------------
// Back layer
// ---------------------------------------------------------------------------
export const ZombieBack: React.FC<{pose: Pose}> = ({pose}) => {
  const m = getMouth(pose.smile, pose.jaw);
  const U = 565;
  const Cn = m.chinY;

  const face =
    `M 400 150 C 535 150 592 235 588 340 C 586 420 568 470 566 545 L 566 ${U + 10} ` +
    `C 560 ${Cn - 90} 500 ${Cn - 10} 440 ${Cn - 4} Q 400 ${Cn + 14} 360 ${Cn - 4} ` +
    `C 300 ${Cn - 10} 240 ${Cn - 90} 234 ${U + 10} L 234 545 ` +
    `C 232 470 214 420 212 340 C 208 235 265 150 400 150 Z`;

  return (
    <g transform={bodyTransform(pose)} strokeLinejoin="round" strokeLinecap="round">
      <defs>
        <radialGradient id="zFace" cx="0.5" cy="0.3" r="0.8">
          <stop offset="0" stopColor={C.skinLight} />
          <stop offset="0.55" stopColor={C.skin} />
          <stop offset="1" stopColor={C.skinDark} />
        </radialGradient>
        <radialGradient id="zEye" cx="0.5" cy="0.45" r="0.6">
          <stop offset="0" stopColor="#faf4bd" />
          <stop offset="0.75" stopColor={C.eye} />
          <stop offset="1" stopColor={C.eyeEdge} />
        </radialGradient>
        <radialGradient id="zMouth" cx="0.5" cy="0.4" r="0.7">
          <stop offset="0" stopColor="#000" />
          <stop offset="1" stopColor="#0d0712" />
        </radialGradient>
        <linearGradient id="zShirt" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={C.shirtLight} />
          <stop offset="1" stopColor={C.shirt} />
        </linearGradient>
        <clipPath id="zMouthClipBack">
          <path d={m.path} />
        </clipPath>
      </defs>

      <Body />

      {/* shadow cast by the chin on the neck / chest */}
      <ellipse cx={400} cy={Cn + 20} rx={92} ry={20} fill="#000" opacity={0.35} />

      <g transform={headTransform(pose)}>
        {/* ears */}
        <path d="M 218 385 L 168 350 L 176 432 L 214 452 Z" fill={C.skinDark} stroke={C.outline} strokeWidth={5} />
        <path d="M 582 395 L 634 358 L 628 442 L 586 460 Z" fill={C.skinDark} stroke={C.outline} strokeWidth={5} />

        {/* face (jaw stretches with the mouth) */}
        <path d={face} fill="url(#zFace)" stroke={C.outline} strokeWidth={6} />

        {/* sunken skeletal shading */}
        <path d="M 232 468 Q 262 530 322 548 Q 280 505 254 440 Z" fill="#1e3220" opacity={0.5} />
        <path d="M 568 468 Q 538 530 478 548 Q 520 505 546 440 Z" fill="#1e3220" opacity={0.5} />
        <path d="M 224 300 Q 236 340 232 372 M 576 300 Q 566 340 570 378" stroke={C.skinShadow} strokeWidth={9} fill="none" opacity={0.6} />
        {/* chin crease */}
        <path d={`M 366 ${m.bottom + 62} Q 400 ${m.bottom + 76} 434 ${m.bottom + 62}`} stroke={C.skinShadow} strokeWidth={5} fill="none" opacity={0.8} />
        {/* hatching */}
        <path d="M 262 500 l 14 14 M 276 496 l 14 14 M 290 500 l 12 12 M 538 500 l -14 14 M 524 496 l -14 14 M 510 500 l -12 12"
          stroke={C.skinShadow} strokeWidth={3} fill="none" opacity={0.7} />
        {/* stitched scar */}
        <path d="M 520 452 Q 545 488 558 530" stroke="#2a1616" strokeWidth={5} fill="none" />
        <path d="M 513 462 l 16 -8 M 527 478 l 16 -8 M 538 494 l 16 -8 M 546 510 l 16 -8 M 552 524 l 14 -6"
          stroke="#2a1616" strokeWidth={4} fill="none" />

        {/* eyes: deliberately asymmetrical */}
        <Eye id="zEyeL" cx={318} cy={386} rx={62} ry={50} rot={-6} pupilR={11} lookX={pose.lookX} lookY={pose.lookY} pose={pose}
          veins="M -58 -6 L -30 -2 M -52 18 L -26 8 M 8 -44 L 4 -26" />
        <Eye id="zEyeR" cx={488} cy={394} rx={48} ry={60} rot={5} pupilR={8} lookX={pose.lookX + 4} lookY={pose.lookY + 2} pose={pose}
          veins="M 44 -8 L 22 -4 M 38 22 L 18 12 M -6 -56 L -2 -36" />

        {/* heavy brow ridges (raise when the mouth opens) */}
        <g transform={`translate(0 ${pose.brow})`}>
          <path d="M 246 326 Q 312 286 386 324" stroke={C.outline} strokeWidth={17} fill="none" />
          <path d="M 246 326 Q 312 286 386 324" stroke={C.skinShadow} strokeWidth={10} fill="none" />
          <path d="M 438 336 Q 502 292 556 322" stroke={C.outline} strokeWidth={17} fill="none" />
          <path d="M 438 336 Q 502 292 556 322" stroke={C.skinShadow} strokeWidth={10} fill="none" />
        </g>

        {/* skeletal nose cavity */}
        <path d="M 400 438 L 382 484 Q 400 470 418 486 Z" fill="#0f180f" stroke={C.outline} strokeWidth={4} />

        {/* mouth interior: deep black */}
        <path d={m.path} fill="url(#zMouth)" />
        <g clipPath="url(#zMouthClipBack)">
          <ellipse cx={400} cy={m.bottom + 8} rx={m.w * 0.55} ry={30 + pose.jaw * 0.28} fill="#2b0f1e" />
          <ellipse cx={400} cy={m.bottom - 6 - pose.jaw * 0.1} rx={m.w * 0.3} ry={6 + pose.jaw * 0.05} fill="#4a1b31" opacity={0.7} />
        </g>

        {/* messy short black hair */}
        <path
          d="M 205 335 L 188 250 L 224 264 L 214 188 L 262 214 L 262 138 L 316 174 L 334 104 L 380 150 L 410 86 L 452 150 L 496 98 L 506 164 L 562 128 L 548 200 L 602 204 L 576 262 L 614 286 L 592 342 L 560 300 L 540 262 L 506 302 L 470 250 L 430 294 L 400 246 L 360 286 L 322 250 L 290 302 L 262 266 L 236 308 Z"
          fill={C.hair}
          stroke={C.hairRim}
          strokeWidth={5}
        />
        <path d="M 300 190 L 322 232 M 420 130 L 436 178 M 520 170 L 536 210 M 250 232 L 270 262" stroke="#4c4c5e" strokeWidth={4} fill="none" />
      </g>
    </g>
  );
};

// ---------------------------------------------------------------------------
// Front layer: teeth + lips
// ---------------------------------------------------------------------------
const UPPER = [
  {len: 34, rot: -5, k: 1},
  {len: 42, rot: 4, k: 1},
  {len: 30, rot: -8, k: 0.9},
  {len: 46, rot: 2, k: 1.05},
  {len: 38, rot: 8, k: 1},
  {len: 44, rot: -3, k: 1, broken: true}, // the broken tooth
  {len: 32, rot: 7, k: 0.92},
  {len: 40, rot: -6, k: 1},
];
const LOWER = [
  {len: 26, rot: 6, k: 0.9},
  {len: 34, rot: -5, k: 1},
  {len: 0, rot: 0, k: 0}, // missing tooth
  {len: 30, rot: 7, k: 0.95},
  {len: 24, rot: -8, k: 0.9},
  {len: 32, rot: 5, k: 1},
];

const Tooth: React.FC<{len: number; w: number; broken?: boolean}> = ({len, w, broken}) => {
  const h = w / 2;
  if (broken) {
    return (
      <g>
        <path
          d={`M ${-h} 0 L ${h} 0 L ${h * 0.92} ${len * 0.5} L ${h * 0.4} ${len * 0.74} L ${h * 0.05} ${len * 0.46} L ${-h * 0.5} ${len * 0.82} L ${-h * 0.92} ${len * 0.58} Z`}
          fill={C.tooth}
          stroke="#2b2208"
          strokeWidth={3.5}
        />
        <path d={`M ${h * 0.05} 2 L ${-h * 0.05} ${len * 0.4} L ${h * 0.05} ${len * 0.46}`} stroke={C.toothDark} strokeWidth={3} fill="none" />
      </g>
    );
  }
  return (
    <g>
      <path
        d={`M ${-h} 0 L ${h} 0 L ${h * 0.92} ${len - 8} Q ${h * 0.9} ${len} ${h * 0.4} ${len} L ${-h * 0.4} ${len} Q ${-h * 0.9} ${len} ${-h * 0.92} ${len - 8} Z`}
        fill={C.tooth}
        stroke="#2b2208"
        strokeWidth={3.5}
      />
      <path d={`M ${-h * 0.5} 6 L ${-h * 0.45} ${len * 0.6}`} stroke={C.toothDark} strokeWidth={3} fill="none" opacity={0.7} />
    </g>
  );
};

export const ZombieFront: React.FC<{pose: Pose}> = ({pose}) => {
  const m = getMouth(pose.smile, pose.jaw);
  const span = m.Rx - m.Lx;
  const nU = UPPER.length;
  const nL = LOWER.length;
  const tw = Math.min(37, (span / nU) * 0.98);

  return (
    <g transform={bodyTransform(pose)} strokeLinejoin="round" strokeLinecap="round">
      <defs>
        <clipPath id="zMouthClipFront">
          <path d={m.path} />
        </clipPath>
      </defs>
      <g transform={headTransform(pose)}>
        <g clipPath="url(#zMouthClipFront)">
          {/* crooked lower row (drawn first so the upper row overlaps it in a grin) */}
          {LOWER.map((t, i) => {
            if (t.len === 0) return null;
            const x = m.Lx + ((i + 0.5) / nL) * span;
            const y = m.lowerY(x);
            return (
              <g key={`l${i}`} transform={`translate(${x} ${y + 5}) rotate(${t.rot}) scale(1 -1)`}>
                <Tooth len={t.len} w={tw * 0.9 * t.k} />
              </g>
            );
          })}
          {/* crooked upper row */}
          {UPPER.map((t, i) => {
            const [x, y] = m.upperPoint((i + 0.5) / nU);
            return (
              <g key={`u${i}`} transform={`translate(${x} ${y - 5}) rotate(${t.rot})`}>
                <Tooth len={t.len} w={tw * t.k} broken={t.broken} />
              </g>
            );
          })}
        </g>
        {/* lip line */}
        <path d={m.path} fill="none" stroke={C.outline} strokeWidth={7} />
        {/* grin lines at the corners */}
        <g opacity={clamp01(pose.smile)} stroke={C.outline} strokeWidth={4.5} fill="none">
          <path d={`M ${m.Lx - 6} ${m.cornerY - 4} Q ${m.Lx - 30} ${m.cornerY + 8} ${m.Lx - 24} ${m.cornerY + 42}`} />
          <path d={`M ${m.Rx + 6} ${m.cornerY - 4} Q ${m.Rx + 30} ${m.cornerY + 8} ${m.Rx + 24} ${m.cornerY + 42}`} />
        </g>
      </g>
    </g>
  );
};
