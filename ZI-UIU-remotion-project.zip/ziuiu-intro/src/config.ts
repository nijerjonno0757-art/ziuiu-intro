// Single source of truth for the composition settings.
export const COMPOSITION_ID = "ZIUIUIntro";
export const FPS = 30;
export const DURATION_SECONDS = 10;
export const DURATION_IN_FRAMES = FPS * DURATION_SECONDS; // 300
export const WIDTH = 1080;
export const HEIGHT = 1920;

export const TITLE_TEXT = "ZI-UIU";
