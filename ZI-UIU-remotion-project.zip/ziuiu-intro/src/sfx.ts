/**
 * Sound-design timeline. All files are procedurally synthesised by
 * scripts/generate-sfx.py (no samples, no external services) and live in public/sfx/.
 * Keep `from` / `volume` in sync with TIMELINE in that script (it also writes
 * docs/audio-mix-preview.wav, a full 10 s preview of this exact mix).
 */
export interface Sfx {
  file: string;
  from: number; // start frame (30 fps)
  frames: number; // length of the file in frames
  volume: number;
  cue: string;
}

export const SFX: ReadonlyArray<Sfx> = [
  {file: "ambient_drone", from: 0, frames: 300, volume: 0.4, cue: "Low unsettling drone bed, swells at the mouth/title, fades with the picture"},
  {file: "rise_scrape", from: 0, frames: 69, volume: 0.85, cue: "Zombie crawls up out of the dirt: rumble, scrape, crumbling grains"},
  {file: "heartbeat", from: 76, frames: 30, volume: 0.75, cue: "Eyes lock onto the camera: double heartbeat"},
  {file: "blink_click", from: 85, frames: 9, volume: 0.55, cue: "Wet eyelid click on the blink"},
  {file: "neck_creak", from: 96, frames: 36, volume: 0.65, cue: "Head tilt: creaking neck + bone cracks"},
  {file: "jaw_stretch", from: 120, frames: 63, volume: 0.7, cue: "Mouth opens wider and wider: stretching leather, groan, wet smacks, tremble"},
  {file: "pop_burst", from: 178, frames: 30, volume: 0.7, cue: "Inhale, then slimy pop as the title bursts out of the mouth"},
  {file: "title_whoosh", from: 181, frames: 27, volume: 0.5, cue: "Title flies toward the viewer"},
  {file: "title_land", from: 206, frames: 48, volume: 0.72, cue: "Title lands: heavy thud, cartoon boing, neon sign flicker"},
  {file: "jaw_clack", from: 236, frames: 12, volume: 0.7, cue: "Jaw snaps shut into the grin: teeth clack"},
  {file: "peek_slide", from: 236, frames: 39, volume: 0.5, cue: "Zombie shuffles aside behind the title"},
  {file: "creepy_giggle", from: 255, frames: 45, volume: 0.55, cue: "Raspy giggle while peeking from behind the title"},
];
