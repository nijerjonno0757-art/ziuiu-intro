import {Easing, interpolate} from "remotion";

const CLAMP = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;

export type Easer = (t: number) => number;

export const inOutCubic: Easer = Easing.inOut(Easing.cubic);
export const inOutSine: Easer = Easing.inOut(Easing.sin);
export const outCubic: Easer = Easing.out(Easing.cubic);

/** Clamped, eased tween between two frames. */
export const tween = (
  frame: number,
  [f0, f1]: readonly [number, number],
  [v0, v1]: readonly [number, number],
  easing: Easer = inOutCubic,
): number => interpolate(frame, [f0, f1], [v0, v1], {...CLAMP, easing});

/** Piece-wise keyframes: [frame, value] pairs, each segment eased. */
export const keyframes = (
  frame: number,
  keys: ReadonlyArray<readonly [number, number]>,
  easing: Easer = inOutCubic,
): number => {
  if (frame <= keys[0][0]) return keys[0][1];
  for (let i = 0; i < keys.length - 1; i++) {
    const [f0, v0] = keys[i];
    const [f1, v1] = keys[i + 1];
    if (frame <= f1) {
      return interpolate(frame, [f0, f1], [v0, v1], {...CLAMP, easing});
    }
  }
  return keys[keys.length - 1][1];
};

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
