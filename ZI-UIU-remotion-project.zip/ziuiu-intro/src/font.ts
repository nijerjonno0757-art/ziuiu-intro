import {useEffect, useState} from "react";
import {cancelRender, continueRender, delayRender, staticFile} from "remotion";

export const TITLE_FONT = "Bangers";
export const TITLE_FONT_STACK = `${TITLE_FONT}, Impact, "Arial Black", sans-serif`;

/** Loads the bundled Bangers font (public/fonts) before any frame is rendered. */
export const useTitleFont = () => {
  const [handle] = useState(() => delayRender("Loading Bangers font"));
  useEffect(() => {
    const face = new FontFace(
      TITLE_FONT,
      `url(${staticFile("fonts/bangers-latin-400-normal.woff2")}) format("woff2")`,
    );
    face
      .load()
      .then((loaded) => {
        (document.fonts as unknown as {add: (f: FontFace) => void}).add(loaded);
        continueRender(handle);
      })
      .catch((err) => cancelRender(err));
  }, [handle]);
};
