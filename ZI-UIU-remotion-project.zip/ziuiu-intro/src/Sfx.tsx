import React from "react";
import {Audio, Sequence, staticFile} from "remotion";
import {SFX} from "./sfx";

/** Plays the whole sound design; each cue is one <Sequence> so it is trivial to retime. */
export const Sfx: React.FC = () => (
  <>
    {SFX.map((s) => (
      <Sequence key={s.file} from={s.from} durationInFrames={s.frames} layout="none">
        <Audio src={staticFile(`sfx/${s.file}.wav`)} volume={s.volume} />
      </Sequence>
    ))}
  </>
);
