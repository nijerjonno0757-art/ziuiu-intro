/**
 * Mouth geometry in the zombie's local coordinate space (800 x 1250 units).
 * Shared by the zombie renderer and the title animation, so the title can pop
 * out of the exact centre of the mouth.
 */
export const MOUTH_X = 400;
export const UPPER_LIP_Y = 565; // resting height of the upper lip
export const MAX_JAW = 250;
const K = 0.5523; // bezier circle constant

export interface MouthGeom {
  w: number;
  Lx: number;
  Rx: number;
  cornerY: number;
  topCtrlY: number;
  bottom: number;
  chinY: number;
  path: string;
  center: [number, number];
  upperPoint: (t: number) => [number, number];
  lowerY: (x: number) => number;
}

export const getMouth = (smile: number, jaw: number): MouthGeom => {
  const U = UPPER_LIP_Y;
  const w = 88 + smile * 52 + jaw * 0.12;
  const Lx = MOUTH_X - w;
  const Rx = MOUTH_X + w;
  const cornerY = U - smile * 24 - jaw * 0.04;
  const topCtrlY = U + 14 * smile - jaw * 0.1;
  const bottom = U + 10 + smile * 34 + jaw;
  const dy = bottom - cornerY;

  const path =
    `M ${Lx} ${cornerY} Q ${MOUTH_X} ${topCtrlY} ${Rx} ${cornerY} ` +
    `C ${Rx} ${cornerY + dy * K} ${MOUTH_X + K * w} ${bottom} ${MOUTH_X} ${bottom} ` +
    `C ${MOUTH_X - K * w} ${bottom} ${Lx} ${cornerY + dy * K} ${Lx} ${cornerY} Z`;

  const upperPoint = (t: number): [number, number] => {
    const a = (1 - t) * (1 - t);
    const b = 2 * t * (1 - t);
    const c = t * t;
    return [
      a * Lx + b * MOUTH_X + c * Rx,
      a * cornerY + b * topCtrlY + c * cornerY,
    ];
  };

  // y of the lower lip curve at a given x (sampled bezier, symmetric)
  const lowerY = (x: number): number => {
    const dx = Math.min(w, Math.abs(x - MOUTH_X));
    let best = bottom;
    let bestErr = Infinity;
    for (let i = 0; i <= 32; i++) {
      const t = i / 32;
      const m = 1 - t;
      const bx =
        m * m * m * 0 +
        3 * m * m * t * (K * w) +
        3 * m * t * t * w +
        t * t * t * w;
      const by =
        m * m * m * bottom +
        3 * m * m * t * bottom +
        3 * m * t * t * (cornerY + dy * K) +
        t * t * t * cornerY;
      const err = Math.abs(bx - dx);
      if (err < bestErr) {
        bestErr = err;
        best = by;
      }
    }
    return best;
  };

  const midTop = 0.5 * cornerY + 0.5 * topCtrlY;
  return {
    w,
    Lx,
    Rx,
    cornerY,
    topCtrlY,
    bottom,
    chinY: bottom + 150,
    path,
    center: [MOUTH_X, (midTop + bottom) / 2],
    upperPoint,
    lowerY,
  };
};
