#!/usr/bin/env python3
"""
Procedurally synthesises every sound effect of the ZI-UIU intro (no samples, no APIs).
    python3 scripts/generate-sfx.py        # needs numpy + scipy
Writes 16-bit mono 44.1 kHz WAVs to public/sfx/ and a preview mix to docs/.
Edit the timeline in TIMELINE below (keep it in sync with src/sfx.ts).
"""
import json, os, wave
import numpy as np
from scipy import signal

SR = 44100
FPS = 30
rng = np.random.default_rng(1307)
OUT = os.path.join(os.path.dirname(__file__), "..", "public", "sfx")
DOCS = os.path.join(os.path.dirname(__file__), "..", "docs")
os.makedirs(OUT, exist_ok=True)
os.makedirs(DOCS, exist_ok=True)


# ----------------------------------------------------------------- helpers
def T(d):
    return np.arange(int(SR * d)) / SR

def noise(d):
    return rng.standard_normal(int(SR * d))

def bp(x, lo, hi, order=2):
    return signal.sosfilt(signal.butter(order, [lo, hi], "band", fs=SR, output="sos"), x)

def lp(x, fc, order=2):
    return signal.sosfilt(signal.butter(order, fc, "low", fs=SR, output="sos"), x)

def hp(x, fc, order=2):
    return signal.sosfilt(signal.butter(order, fc, "high", fs=SR, output="sos"), x)

def curve(t, pts):
    """Piece-wise linear gain curve from [(seconds, value), ...]."""
    xs, ys = zip(*pts)
    return np.interp(t, xs, ys)

def fade(x, a=0.005, b=0.01):
    n = len(x)
    g = np.ones(n)
    na, nb = int(a * SR), int(b * SR)
    if na: g[:na] = np.linspace(0, 1, na)
    if nb: g[-nb:] *= np.linspace(1, 0, nb)
    return x * g

def peak(x, p=0.9):
    m = np.max(np.abs(x)) or 1
    return x / m * p

def osc(freq_t, shape="sin"):
    ph = 2 * np.pi * np.cumsum(freq_t) / SR
    if shape == "saw":
        return 2 * ((ph / (2 * np.pi)) % 1) - 1
    return np.sin(ph)

def reverb(x, decay=0.7, mix=0.25):
    n = int(decay * SR)
    ir = lp(rng.standard_normal(n), 3500) * np.exp(-np.linspace(0, 7, n))
    ir[0] = 0
    wet = signal.fftconvolve(x, ir)[: len(x)]
    wet = wet / (np.max(np.abs(wet)) or 1) * np.max(np.abs(x))
    return x * (1 - mix) + wet * mix

def sweep_noise(d, f0, f1, width_oct=0.9, bands=28, lo=60, hi=9000):
    """Noise whose spectral centre glides f0 -> f1 (filter-bank, smooth, no clicks)."""
    t = T(d)
    n = noise(d)
    centres = np.geomspace(lo, hi, bands)
    fc_t = np.geomspace(f0, f1, len(t))
    out = np.zeros(len(t))
    for c in centres:
        band = bp(n, c / 1.25, min(c * 1.25, SR / 2 - 100), 2)
        g = np.exp(-0.5 * (np.log2(c / fc_t) / width_oct) ** 2)
        out += band * g
    return out

def stick_slip(d, rate_t, f_lo, f_hi, jitter=0.5):
    """Creaky friction: jittered impulse train excited into a resonant band."""
    n = int(SR * d)
    imp = np.zeros(n)
    i = 0
    while i < n:
        imp[i] = rng.uniform(0.4, 1.0)
        r = rate_t[min(i, n - 1)] * (1 + rng.uniform(-jitter, jitter))
        i += max(1, int(SR / r))
    # short decaying ring of the resonance after each impulse
    ring = bp(imp, f_lo, f_hi, 3)
    return ring

def click(d=0.12, lo=1500, hi=5500, body=300, decay=70, amp=1.0):
    t = T(d)
    c = bp(noise(d), lo, hi) * np.exp(-decay * t)
    b = np.sin(2 * np.pi * (body * (1 + 1.6 * np.exp(-40 * t))) * t) * np.exp(-decay * 0.7 * t)
    return amp * (c + 0.7 * b)

def place(buf, x, at):
    i = int(at * SR)
    j = min(len(buf), i + len(x))
    if i < len(buf):
        buf[i:j] += x[: j - i]

sounds = {}

# ------------------------------------------------- 1. ambient drone (10 s)
def ambient():
    d = 10.0
    t = T(d)
    drift = 0.8 * np.sin(2 * np.pi * 0.13 * t)
    base = (
        0.55 * np.sin(2 * np.pi * 55 * t + drift)
        + 0.40 * np.sin(2 * np.pi * 55.9 * t)           # slow beating = unease
        + 0.28 * np.sin(2 * np.pi * 82.4 * t + 0.3 * drift)
        + 0.20 * np.sin(2 * np.pi * 77.8 * t)            # tritone-ish clash
    )
    base *= 1 + 0.18 * np.sin(2 * np.pi * 0.31 * t)
    wind = lp(bp(noise(d), 180, 1100), 900) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.17 * t + 1)) * 0.35
    # thin dissonant whine that tightens while the mouth opens (4-6 s), cut by the pop
    wf = 1760 + 380 * np.clip((t - 4) / 2, 0, 1)
    whine = np.sin(2 * np.pi * np.cumsum(wf) / SR) * curve(t, [(0, 0), (2, 0), (6.0, 0.07), (6.05, 0.0), (10, 0)])
    mix = base + wind + whine
    swell = curve(t, [(0, 0), (1.0, 0.45), (4.0, 0.6), (6.0, 1.0), (6.2, 0.9), (8.0, 0.65), (9.07, 0.55), (10.0, 0.0)])
    return peak(mix * swell, 0.55)

# ----------------------------------------------- 2. zombie rises from dirt
def rise_scrape():
    d = 2.3
    t = T(d)
    rumble = lp(noise(d), 160, 3) * 1.2
    scrape = sweep_noise(d, 350, 900, 1.0)
    # crumbling dirt grains, denser while the zombie moves fastest
    dens = curve(t, [(0, 20), (1.0, 220), (2.3, 30)])
    grains = np.zeros(len(t))
    idx = np.where(rng.random(len(t)) < dens / SR)[0]
    for i in idx:
        g = click(0.03, 1200, 6000, 500, 160, rng.uniform(0.3, 1.0))
        grains[i : i + len(g)] += g[: len(grains) - i]
    env = curve(t, [(0, 0), (0.8, 0.55), (1.3, 1.0), (2.0, 0.35), (2.3, 0)])
    return peak((0.8 * rumble + 0.5 * scrape + 0.35 * grains) * env, 0.85)

# --------------------------------------------- 3. heartbeat when it stares
def heartbeat():
    d = 1.0
    t = T(d)
    out = np.zeros(len(t))
    for at, amp in [(0.0, 1.0), (0.27, 0.7)]:
        tt = T(0.5)
        f = 48 + 70 * np.exp(-28 * tt)
        th = osc(f) * np.exp(-9 * tt) * (1 - np.exp(-400 * tt))
        place(out, th * amp, at)
    return peak(fade(out, 0.002, 0.05), 0.9)

# ------------------------------------------------------ 4. wet eyelid blink
def blink():
    d = 0.3
    out = np.zeros(int(SR * d))
    place(out, click(0.1, 900, 3800, 700, 90, 1.0) * 0.8, 0.0)       # lid closes
    place(out, click(0.1, 1400, 5000, 900, 110, 1.0) * 0.55, 0.14)   # lid opens
    return peak(fade(out), 0.8)

# ---------------------------------------- 5. head tilt: neck creak + cracks
def neck_creak():
    d = 1.2
    t = T(d)
    rate = 28 + 40 * np.sin(np.pi * np.clip(t / 0.9, 0, 1))
    creak = stick_slip(d, rate, 500, 1700, 0.6)
    creak = creak / (np.max(np.abs(creak)) or 1)
    creak *= curve(t, [(0, 0), (0.15, 0.7), (0.8, 1.0), (1.0, 0.0), (1.2, 0)])
    out = creak * 0.8
    for at, amp in [(0.12, 0.9), (0.38, 1.0), (0.62, 0.8)]:       # bone cracks
        place(out, click(0.09, 700, 3500, 160, 85, amp), at)
    return peak(fade(reverb(out, 0.4, 0.15)), 0.8)

# ------------------------------- 6. mouth stretches wider and wider (2 s)
def jaw_stretch():
    d = 2.1
    t = T(d)
    prog = np.clip(t / 2.0, 0, 1)
    rate = 14 + 60 * prog ** 1.6
    lo = 300 + 700 * prog
    sq = np.zeros(len(t))
    # stick-slip friction, resonance climbing with the stretch (done in 3 chunks)
    chunk = len(t) // 3
    for k in range(3):
        a, b = k * chunk, (k + 1) * chunk if k < 2 else len(t)
        seg = stick_slip((b - a) / SR, rate[a:b], lo[a] , lo[a] * 2.1, 0.5)
        sq[a : a + len(seg)] += seg[: b - a]
    sq /= (np.max(np.abs(sq)) or 1)
    groan = lp(osc(45 + 30 * prog, "saw"), 220, 2) * (0.3 + 0.7 * prog)
    wet = np.zeros(len(t))
    for at in np.sort(rng.uniform(0.2, 1.9, 9) ** 1.0):
        place(wet, click(0.07, 400, 2400, 220, 60, 0.4 + 0.5 * at / 2), at)
    trem = 1 + 0.35 * np.sin(2 * np.pi * 14 * t) * prog                # nervous tremble
    env = curve(t, [(0, 0), (0.3, 0.12), (1.2, 0.4), (1.9, 1.0), (2.0, 1.0), (2.1, 0.0)])
    out = (0.9 * sq * env * trem + 0.8 * groan * env + 0.5 * wet)
    return peak(fade(reverb(out, 0.5, 0.18)), 0.85)

# ----------------------------------- 7. slimy pop out of the mouth (burst)
def pop_burst():
    d = 1.0
    t = T(d)
    out = np.zeros(len(t))
    inhale = sweep_noise(0.09, 400, 2500) * np.linspace(0, 1, int(0.09 * SR)) ** 2
    place(out, inhale * 0.6, 0.0)                                         # sucking in
    tp = T(0.45)
    bloop = osc(140 + 900 * np.exp(-15 * tp)) * np.exp(-9 * tp)
    splat = bp(noise(0.45), 350, 4200) * np.exp(-20 * tp)
    thump = osc(70 + 80 * np.exp(-25 * tp)) * np.exp(-12 * tp)
    place(out, 1.0 * bloop + 0.9 * splat + 0.8 * thump, 0.09)
    for at, f in [(0.30, 1250), (0.42, 980), (0.52, 1500), (0.66, 1100), (0.78, 1350)]:   # slime plips
        td = T(0.09)
        place(out, osc(f * (1.5 - 1.0 * td / 0.09)) * np.exp(-38 * td) * 0.35, at)
    return peak(fade(reverb(out, 0.5, 0.2)), 0.95)

# ------------------------------- 8. title flies at the viewer (whoosh)
def title_whoosh():
    d = 0.9
    t = T(d)
    w = sweep_noise(d, 250, 4200, 0.8)
    env = curve(t, [(0, 0), (0.15, 0.25), (0.8, 1.0), (0.87, 0.9), (0.9, 0.0)])
    hum = osc(80 + 260 * (t / d) ** 2) * 0.5
    return peak(fade((w * 0.9 + hum) * env, 0.003, 0.005), 0.8)

# ---------------- 9. title lands: thud + boing + neon flicker-zap
def title_land():
    d = 1.6
    t = T(d)
    out = np.zeros(len(t))
    ti = T(0.7)
    thud = osc(62 * np.exp(-3.5 * ti) + 30) * np.exp(-5.5 * ti)
    crack = bp(noise(0.7), 900, 6000) * np.exp(-45 * ti)
    place(out, 1.0 * thud + 0.55 * crack, 0.0)
    for at, amp in [(0.21, 0.5), (0.42, 0.25)]:                          # squash rebounds
        tb = T(0.35)
        place(out, osc(55 + 25 * np.exp(-20 * tb)) * np.exp(-12 * tb) * amp, at)
    tb = T(1.1)
    vib = 1 + 0.38 * np.exp(-4.5 * tb) * np.sin(2 * np.pi * 4.8 * tb)    # cartoon boing
    boing = osc(230 * vib * (1 + 0.5 * np.exp(-6 * tb)), "sin") * np.exp(-3.6 * tb)
    boing += 0.4 * osc(460 * vib * (1 + 0.5 * np.exp(-6 * tb))) * np.exp(-5 * tb)
    place(out, boing * 0.55, 0.0)
    # neon sign flicker
    fl = np.zeros(len(t))
    for a, b in [(0.06, 0.16), (0.30, 0.38), (0.52, 0.66), (0.80, 0.86)]:
        n = int((b - a) * SR)
        buzz = hp(np.sign(np.sin(2 * np.pi * 100 * np.arange(n) / SR)) + 0.7 * noise(n / SR), 700)
        place(fl, buzz * np.hanning(n) * 0.22, a)
    out += fl
    return peak(fade(reverb(out, 0.6, 0.18)), 0.95)

# --------------------------------------- 10. jaw snaps shut (teeth clack)
def jaw_clack():
    d = 0.4
    out = np.zeros(int(SR * d))
    place(out, click(0.12, 1200, 5000, 380, 55, 1.0), 0.03)
    place(out, click(0.1, 1500, 5500, 420, 70, 0.6), 0.10)
    place(out, click(0.08, 1500, 5500, 460, 80, 0.35), 0.16)
    return peak(fade(out), 0.85)

# -------------------------- 11. zombie shuffles aside (cloth + dirt scrape)
def peek_slide():
    d = 1.3
    t = T(d)
    s = sweep_noise(d, 700, 260, 0.9)
    env = curve(t, [(0, 0), (0.25, 0.8), (0.6, 1.0), (1.0, 0.3), (1.3, 0)])
    cr = stick_slip(d, 22 + 0 * t, 380, 900, 0.7)
    cr = cr / (np.max(np.abs(cr)) or 1) * 0.35
    return peak(fade((s * 0.9 + cr) * env, 0.01, 0.05), 0.6)

# -------------------------------- 12. creepy raspy giggle from behind title
def creepy_giggle():
    d = 1.5
    t = T(d)
    out = np.zeros(len(t))
    starts = [0.0, 0.27, 0.54, 0.81]
    amps = [1.0, 0.85, 0.65, 0.45]
    for k, (a, amp) in enumerate(zip(starts, amps)):
        n = T(0.2)
        f0 = 235 - 28 * k
        f = f0 * (1 + 0.18 * np.linspace(0, 1, len(n)) ** 0.6) + 4 * np.sin(2 * np.pi * 38 * n)
        voice = osc(f, "saw")
        vowel = bp(voice, 650, 1050, 2) * 1.0 + bp(voice, 2100, 2800, 2) * 0.7   # "ee"-like formants
        breath = bp(noise(0.2), 3500, 7500) * 0.35
        env = np.sin(np.pi * np.linspace(0, 1, len(n))) ** 1.4
        place(out, (vowel + breath) * env * amp, a)
    hiss = bp(noise(0.5), 3000, 7000) * curve(T(0.5), [(0, 0), (0.1, 0.5), (0.5, 0)]) * 0.35
    place(out, hiss, 1.0)                                                     # exhale
    return peak(fade(reverb(out, 0.5, 0.2)), 0.7)

BUILD = {
    "ambient_drone": ambient,
    "rise_scrape": rise_scrape,
    "heartbeat": heartbeat,
    "blink_click": blink,
    "neck_creak": neck_creak,
    "jaw_stretch": jaw_stretch,
    "pop_burst": pop_burst,
    "title_whoosh": title_whoosh,
    "title_land": title_land,
    "jaw_clack": jaw_clack,
    "peek_slide": peek_slide,
    "creepy_giggle": creepy_giggle,
}

# (file, start frame, volume)  -> keep identical to src/sfx.ts
TIMELINE = [
    ("ambient_drone", 0, 0.40),
    ("rise_scrape", 0, 0.85),
    ("heartbeat", 76, 0.75),
    ("blink_click", 85, 0.55),
    ("neck_creak", 96, 0.65),
    ("jaw_stretch", 120, 0.70),
    ("pop_burst", 178, 0.70),
    ("title_whoosh", 181, 0.50),
    ("title_land", 206, 0.72),
    ("jaw_clack", 236, 0.70),
    ("peek_slide", 236, 0.50),
    ("creepy_giggle", 255, 0.55),
]

def write_wav(path, x):
    pcm = (np.clip(x, -1, 1) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(pcm.tobytes())

if __name__ == "__main__":
    manifest = {}
    for name, fn in BUILD.items():
        x = fn()
        sounds[name] = x
        write_wav(os.path.join(OUT, f"{name}.wav"), x)
        manifest[name] = {"seconds": round(len(x) / SR, 3), "frames": int(np.ceil(len(x) / SR * FPS))}
    # preview mix of the whole 10 s (mirrors the Remotion timeline)
    mix = np.zeros(int(SR * 10))
    for name, start, vol in TIMELINE:
        place(mix, sounds[name] * vol, start / FPS)
    write_wav(os.path.join(DOCS, "audio-mix-preview.wav"), np.clip(mix, -1, 1))
    print(json.dumps(manifest, indent=1))
    print("mix peak: %.3f   rms: %.3f   clipped samples: %d" % (np.max(np.abs(mix)), np.sqrt(np.mean(mix ** 2)), int(np.sum(np.abs(mix) > 1))))
