// Verifies composition settings (static check) and, if present, the rendered MP4 (ffprobe).
import {readFileSync, existsSync} from "node:fs";
import {execFileSync} from "node:child_process";

const cfg = readFileSync("src/config.ts", "utf8");
const pick = (name) => {
  const m = cfg.match(new RegExp(`export const ${name}\\s*=\\s*([^;]+);`));
  if (!m) throw new Error(`Missing ${name} in src/config.ts`);
  return m[1].trim();
};
const FPS = Number(pick("FPS"));
const SECONDS = Number(pick("DURATION_SECONDS"));
const WIDTH = Number(pick("WIDTH"));
const HEIGHT = Number(pick("HEIGHT"));
const ID = pick("COMPOSITION_ID").replace(/"/g, "");
const FRAMES = FPS * SECONDS;

const expect = (label, actual, wanted) => {
  const ok = actual === wanted;
  console.log(`${ok ? "PASS" : "FAIL"}  ${label}: ${actual}${ok ? "" : ` (expected ${wanted})`}`);
  if (!ok) process.exitCode = 1;
};

expect("composition id", ID, "ZIUIUIntro");
expect("fps", FPS, 30);
expect("duration (frames)", FRAMES, 300);
expect("width", WIDTH, 1080);
expect("height", HEIGHT, 1920);

const root = readFileSync("src/Root.tsx", "utf8");
expect("Root uses COMPOSITION_ID", /id=\{COMPOSITION_ID\}/.test(root), true);
const pkg = JSON.parse(readFileSync("package.json", "utf8"));
expect("render script targets ZIUIUIntro h264", /ZIUIUIntro .*--codec=h264/.test(pkg.scripts.render), true);

// every SFX referenced in src/sfx.ts must exist in public/sfx
const sfx = readFileSync("src/sfx.ts", "utf8");
for (const m of sfx.matchAll(/file: "([a-z_]+)"/g)) {
  expect(`sfx file ${m[1]}.wav`, existsSync(`public/sfx/${m[1]}.wav`), true);
}

const out = "out/ZI-UIU.mp4";
if (existsSync(out)) {
  const probe = JSON.parse(
    execFileSync("ffprobe", ["-v", "error", "-show_streams", "-show_format", "-of", "json", out]).toString(),
  );
  const v = probe.streams.find((s) => s.codec_type === "video");
  expect("mp4 codec", v.codec_name, "h264");
  expect("mp4 size", `${v.width}x${v.height}`, `${WIDTH}x${HEIGHT}`);
  expect("mp4 fps", v.r_frame_rate, `${FPS}/1`);
  expect("mp4 frames", Number(v.nb_frames), FRAMES);
  const a = probe.streams.filter((s) => s.codec_type === "audio");
  expect("mp4 audio streams", a.length, 1);
  expect("mp4 audio codec", a[0]?.codec_name, "aac");
  console.log(`INFO  mp4 duration: ${Number(probe.format.duration).toFixed(3)}s`);
} else {
  console.log("INFO  out/ZI-UIU.mp4 not found - run `npm run render` first to verify the video file.");
}
